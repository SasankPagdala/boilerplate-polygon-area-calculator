class Rectangle:
  def __init__(self, width, height):
    self.height = height
    self.width = width
  
  def  __repr__(self):
    return f"Rectangle(width={self.width}, height={self.height})"

  #Defining methods for different parts of Rectangle
  def set_width(self, width):
    self.width = width
    
  def set_height(self, height):
    self.height = height

  def get_area(self):
    return self.width * self.height

  def get_perimeter(self):
    return ((self.width * 2) + (self.height * 2))

  def get_diagonal(self):
    return ((self.width ** 2 + self.height ** 2) ** .5)

  #Formating description of astrics
  def get_picture(self):
    if self.width > 50 or self.height > 50:
      return "Too big for picture."
  
    f = ""
    for x in range(self.height):
        f += "*" * self.width + "\n"
    return f
  
  #Figuring out how many objects can be inside shape itself
  def get_amount_inside(self, shape):
    inscribed_area = shape.height * shape.width
    original_area = self.get_area()
    return original_area // inscribed_area


# r = Rectangle(10, 5)
# print(r.get_amount_inside(5, 5))


#Formating Sqare 
class Square(Rectangle):
  def __init__(self, side_length):
    super().__init__(side_length, side_length)

  def  __repr__(self):
    return f"Square(side={self.width})"

  #Methods regarding Square
  def set_side(self, side_length):
    self.width = side_length 
    self.height = side_length
    
  def set_width(self, side_length):
    self.set_side(side_length)

  def set_height(self, side_length):
    self.set_side(side_length)